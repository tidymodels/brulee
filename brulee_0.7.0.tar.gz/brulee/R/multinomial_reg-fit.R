#' Fit a multinomial regression model
#'
#' `brulee_multinomial_reg()` fits a model.
#'
#' @param x Depending on the context:
#'
#'   * A __data frame__ of predictors.
#'   * A __matrix__ of predictors.
#'   * A __recipe__ specifying a set of preprocessing steps
#'     created from [recipes::recipe()].
#'
#'  The predictor data should be standardized (e.g. centered or scaled).
#'
#' @param y When `x` is a __data frame__ or __matrix__, `y` is the outcome
#' specified as:
#'
#'   * A __data frame__ with 1 factor column (with three or more levels).
#'   * A __matrix__ with 1 factor column (with three or more levels).
#'   * A factor __vector__ (with three or more levels).
#'
#' @param data When a __recipe__ or __formula__ is used, `data` is specified as:
#'
#'   * A __data frame__ containing both the predictors and the outcome.
#' @inheritParams brulee_mlp
#'
#' @param optimizer The method used in the optimization procedure. Possible choices
#'   are `"SGD"`,  `"ADAMw"`, `"Adadelta"`, `"Adagrad"`, `"RMSprop"`, and
#'   `"LBFGS"`. `"LBFGS"` is the only second-order method, does not use
#'   batches, and is the default.
#'
#' @details
#'
#' This function fits a linear combination of coefficients and predictors to
#' model the log of the class probabilities. The training process optimizes the
#' cross-entropy loss function.
#'
#' By default, training halts when the validation loss increases for at least
#' `step_iter` iterations. If `validation = 0` the training set loss is used.
#'
#' The _predictors_ data should all be numeric and encoded in the same units (e.g.
#' standardized to the same range or distribution). If there are factor
#' predictors, use a recipe or formula to create indicator variables (or some
#' other method) to make them numeric. Predictors should be in the same units
#' before training.
#'
#' The model objects are saved for each epoch so that the number of epochs can
#' be efficiently tuned. Both the [coef()] and [predict()] methods for this
#' model have an `epoch` argument (which defaults to the epoch with the best
#' loss value).
#'
#' The use of the L1 penalty (a.k.a. the lasso penalty) does _not_ force
#' parameters to be strictly zero (as it does in packages such as \pkg{glmnet}).
#' The zeroing out of parameters is a specific feature the optimization method
#' used in those packages.
#'
#' @seealso [predict.brulee_multinomial_reg()], [coef.brulee_multinomial_reg()],
#' [autoplot.brulee_multinomial_reg()]
#'
#' @return
#'
#' A `brulee_multinomial_reg` object with elements:
#'  * `models_obj`: a serialized raw vector for the torch module.
#'  * `estimates`: a list of matrices with the model parameter estimates per
#'                 epoch.
#'  * `best_epoch`: an integer for the epoch with the smallest loss.
#'  * `loss`: A vector of loss values (MSE for regression, negative log-
#'            likelihood for classification) at each epoch.
#'  * `dim`: A list of data dimensions.
#'  * `parameters`: A list of some tuning parameter values.
#'  * `blueprint`: The `hardhat` blueprint data.
#'
#' @examplesIf !brulee:::is_cran_check()
#' \donttest{
#' if (torch::torch_is_installed() & rlang::is_installed(c("recipes", "yardstick", "modeldata"))) {
#'
#'   library(recipes)
#'   library(yardstick)
#'
#'   data(penguins, package = "modeldata")
#'
#'   penguins <- penguins |> na.omit()
#'
#'   set.seed(122)
#'   in_train <- sample(1:nrow(penguins), 200)
#'   penguins_train <- penguins[ in_train,]
#'   penguins_test  <- penguins[-in_train,]
#'
#'   rec <- recipe(island ~ ., data = penguins_train) |>
#'     step_dummy(species, sex) |>
#'     step_normalize(all_predictors())
#'
#'   set.seed(3)
#'   fit <- brulee_multinomial_reg(rec, data = penguins_train, epochs = 5)
#'   fit
#'
#'   predict(fit, penguins_test) |>
#'     bind_cols(penguins_test) |>
#'     conf_mat(island, .pred_class)
#' }
#' }
#' @export
brulee_multinomial_reg <- function(x, ...) {
  UseMethod("brulee_multinomial_reg")
}

#' @export
#' @rdname brulee_multinomial_reg
brulee_multinomial_reg.default <- function(x, ...) {
  stop(
    "`brulee_multinomial_reg()` is not defined for a '",
    class(x)[1],
    "'.",
    call. = FALSE
  )
}

# XY method - data frame

#' @export
#' @rdname brulee_multinomial_reg
brulee_multinomial_reg.data.frame <-
  function(
    x,
    y,
    epochs = 20L,
    penalty = 0.001,
    mixture = 0,
    validation = 0.1,
    optimizer = "LBFGS",
    learn_rate = 1.0,
    momentum = 0.0,
    batch_size = NULL,
    class_weights = NULL,
    stop_iter = 5,
    verbose = FALSE,
    device = NULL,
    ...
  ) {
    processed <- hardhat::mold(x, y)

    brulee_multinomial_reg_bridge(
      processed,
      epochs = epochs,
      optimizer = optimizer,
      learn_rate = learn_rate,
      penalty = penalty,
      mixture = mixture,
      validation = validation,
      momentum = momentum,
      batch_size = batch_size,
      class_weights = class_weights,
      stop_iter = stop_iter,
      verbose = verbose,
      device = device,
      ...
    )
  }

# XY method - matrix

#' @export
#' @rdname brulee_multinomial_reg
brulee_multinomial_reg.matrix <- function(
  x,
  y,
  epochs = 20L,
  penalty = 0.001,
  mixture = 0,
  validation = 0.1,
  optimizer = "LBFGS",
  learn_rate = 1,
  momentum = 0.0,
  batch_size = NULL,
  class_weights = NULL,
  stop_iter = 5,
  verbose = FALSE,
  device = NULL,
  ...
) {
  processed <- hardhat::mold(x, y)

  brulee_multinomial_reg_bridge(
    processed,
    epochs = epochs,
    optimizer = optimizer,
    learn_rate = learn_rate,
    momentum = momentum,
    penalty = penalty,
    mixture = mixture,
    validation = validation,
    batch_size = batch_size,
    class_weights = class_weights,
    stop_iter = stop_iter,
    verbose = verbose,
    device = device,
    ...
  )
}

# Formula method

#' @export
#' @rdname brulee_multinomial_reg
brulee_multinomial_reg.formula <-
  function(
    formula,
    data,
    epochs = 20L,
    penalty = 0.001,
    mixture = 0,
    validation = 0.1,
    optimizer = "LBFGS",
    learn_rate = 1,
    momentum = 0.0,
    batch_size = NULL,
    class_weights = NULL,
    stop_iter = 5,
    verbose = FALSE,
    device = NULL,
    ...
  ) {
    processed <- hardhat::mold(formula, data)

    brulee_multinomial_reg_bridge(
      processed,
      epochs = epochs,
      optimizer = optimizer,
      learn_rate = learn_rate,
      momentum = momentum,
      penalty = penalty,
      mixture = mixture,
      validation = validation,
      batch_size = batch_size,
      class_weights = class_weights,
      stop_iter = stop_iter,
      verbose = verbose,
      device = device,
      ...
    )
  }

# Recipe method

#' @export
#' @rdname brulee_multinomial_reg
brulee_multinomial_reg.recipe <-
  function(
    x,
    data,
    epochs = 20L,
    penalty = 0.001,
    mixture = 0,
    validation = 0.1,
    optimizer = "LBFGS",
    learn_rate = 1,
    momentum = 0.0,
    batch_size = NULL,
    class_weights = NULL,
    stop_iter = 5,
    verbose = FALSE,
    device = NULL,
    ...
  ) {
    processed <- hardhat::mold(x, data)

    brulee_multinomial_reg_bridge(
      processed,
      epochs = epochs,
      optimizer = optimizer,
      learn_rate = learn_rate,
      momentum = momentum,
      penalty = penalty,
      mixture = mixture,
      validation = validation,
      batch_size = batch_size,
      class_weights = class_weights,
      stop_iter = stop_iter,
      verbose = verbose,
      device = device,
      ...
    )
  }

# ------------------------------------------------------------------------------
# Bridge

brulee_multinomial_reg_bridge <- function(
  processed,
  epochs,
  optimizer,
  learn_rate,
  momentum,
  penalty,
  mixture,
  class_weights,
  validation,
  batch_size,
  stop_iter,
  verbose,
  device,
  ...,
  call = rlang::caller_env()
) {
  if (!torch::torch_is_installed()) {
    cli::cli_abort(
      "The torch backend has not been installed; use {.run torch::install_torch()}.",
      call = call
    )
  }

  # Guess device if not specified
  device <- guess_brulee_device(device)

  # Validate common arguments
  validated <- validate_common_args(
    epochs = epochs,
    batch_size = batch_size,
    penalty = penalty,
    mixture = mixture,
    validation = validation,
    momentum = momentum,
    learn_rate = learn_rate,
    verbose = verbose,
    call = call
  )

  # Extract validated/coerced values
  epochs <- validated$epochs
  batch_size <- validated$batch_size

  ## -----------------------------------------------------------------------------

  # Process predictors
  predictors <- process_predictors(processed$predictors, call = call)

  ## -----------------------------------------------------------------------------

  # Validate outcome
  outcome <- validate_multiclass_outcome(processed$outcomes[[1]], call = call)

  # ------------------------------------------------------------------------------

  lvls <- levels(outcome)
  xtab <- table(outcome)
  class_weights <- check_class_weights(class_weights, lvls, xtab, call = call)

  ## -----------------------------------------------------------------------------

  fit <-
    multinomial_reg_fit_imp(
      x = predictors,
      y = outcome,
      epochs = epochs,
      optimizer = optimizer,
      learn_rate = learn_rate,
      momentum = momentum,
      penalty = penalty,
      mixture = mixture,
      validation = validation,
      batch_size = batch_size,
      class_weights = class_weights,
      stop_iter = stop_iter,
      verbose = verbose,
      device = device
    )

  new_brulee_multinomial_reg(
    model_obj = fit$model_obj,
    estimates = fit$estimates,
    best_epoch = fit$best_epoch,
    loss = fit$loss,
    dims = fit$dims,
    y_stats = fit$y_stats,
    parameters = fit$parameters,
    device = fit$device,
    blueprint = processed$blueprint
  )
}

new_brulee_multinomial_reg <- function(
  model_obj,
  estimates,
  best_epoch,
  loss,
  dims,
  y_stats,
  parameters,
  device,
  blueprint
) {
  if (!inherits(model_obj, "raw")) {
    cli::cli_abort("{.arg model_obj} should be a raw vector.", call = NULL)
  }
  if (!is.list(estimates)) {
    cli::cli_abort("{.arg estimates} should be a list.", call = NULL)
  }
  if (!is.vector(loss) || !is.numeric(loss)) {
    cli::cli_abort("{.arg loss} should be a numeric vector.", call = NULL)
  }
  if (!is.list(dims)) {
    cli::cli_abort("{.arg dims} should be a list.", call = NULL)
  }
  if (!is.list(parameters)) {
    cli::cli_abort("{.arg parameters} should be a list.", call = NULL)
  }
  if (!inherits(blueprint, "hardhat_blueprint")) {
    cli::cli_abort(
      "{.arg blueprint} should be a hardhat blueprint.",
      call = NULL
    )
  }
  hardhat::new_model(
    model_obj = model_obj,
    estimates = estimates,
    best_epoch = best_epoch,
    loss = loss,
    dims = dims,
    y_stats = y_stats,
    parameters = parameters,
    device = device,
    blueprint = blueprint,
    class = "brulee_multinomial_reg"
  )
}

## -----------------------------------------------------------------------------
# Fit code

multinomial_reg_fit_imp <-
  function(
    x,
    y,
    epochs = 20L,
    batch_size = NULL,
    penalty = 0.001,
    mixture = 0,
    validation = 0.1,
    optimizer = "LBFGS",
    learn_rate = 1,
    momentum = 0.0,
    class_weights = NULL,
    stop_iter = 5,
    verbose = FALSE,
    device = "cpu",
    ...
  ) {
    torch::torch_manual_seed(sample.int(10^5, 1))

    ## ---------------------------------------------------------------------------
    # General data checks:

    check_data_att(x, y)

    # Check missing values
    compl_data <- check_missing_data(x, y, "brulee_multinomial_reg", verbose)
    x <- compl_data$x
    y <- compl_data$y
    n <- length(y)
    p <- ncol(x)

    lvls <- levels(y)
    y_dim <- length(lvls)
    # the model will output softmax values.
    # so we need to use negative likelihood loss and
    # pass the log of softmax.
    loss_fn <- function(input, target, wts = NULL) {
      nnf_nll_loss(
        weight = weights_to_tensor(wts, device = input$device),
        input = torch::torch_log(input),
        target = target
      )
    }

    # Split validation set
    val_split <- split_validation(x, y, validation)
    x <- val_split$x_train
    y <- val_split$y_train
    x_val <- val_split$x_val
    y_val <- val_split$y_val

    y_stats <- list(mean = NA_real_, sd = NA_real_)
    loss_label <- "\tLoss:"

    # Determine batch size
    batch_size <- determine_batch_size(batch_size, optimizer, nrow(x))

    ## ---------------------------------------------------------------------------
    # Set torch dtype for both data and model

    or_dtype <- torch::torch_get_default_dtype()
    on.exit(torch::torch_set_default_dtype(or_dtype))
    torch::torch_set_default_dtype(torch::torch_float32())

    ## ---------------------------------------------------------------------------
    # Build the module on the CPU, then move it to `device`. See the
    # "Device-handling notes" comment block at the top of R/0_utils.R for the
    # full rationale. Short version: parameter initialization inside
    # `with_device(mps, ...)` runs against the MPS RNG, which
    # `torch_manual_seed()` does NOT reliably reset; constructing on the CPU
    # first uses the properly-seeded CPU RNG so seeds give reproducible
    # initial weights on every backend.
    model <- multinomial_module(ncol(x), y_dim)
    model$to(device = device)

    # Set device context for training
    training_output <- torch::with_device(device = device, {
      # Convert to index sampler and data loader
      torch_data <- setup_torch_data(
        x,
        y,
        x_val,
        y_val,
        batch_size,
        validation,
        device = device
      )
      dl <- torch_data$dl
      dl_val <- torch_data$dl_val

      ## -------------------------------------------------------------------------
      # Loss and optimizer (model now lives on the target device)
      loss_fn <- make_penalized_loss(
        loss_fn,
        model,
        penalty,
        mixture,
        optimizer
      )
      optimizer_obj <- set_optimizer(
        optimizer,
        model,
        learn_rate,
        momentum,
        penalty,
        mixture
      )

      ## -------------------------------------------------------------------------

      # Run training loop
      training_result <- run_training_loop(
        model = model,
        dl = dl,
        dl_val = dl_val,
        loss_fn = loss_fn,
        optimizer_obj = optimizer_obj,
        epochs = epochs,
        learn_rate = learn_rate,
        stop_iter = stop_iter,
        validation = validation,
        class_weights = class_weights,
        loss_label = loss_label,
        verbose = verbose,
        ...
      )

      list(
        model = model,
        training_result = training_result
      )
    })

    # ------------------------------------------------------------------------------

    class_weights <- as.numeric(class_weights)
    names(class_weights) <- lvls

    ## ---------------------------------------------------------------------------

    list(
      model_obj = model_to_raw(training_output$model),
      estimates = training_output$training_result$param_per_epoch,
      loss = training_output$training_result$loss_vec,
      best_epoch = training_output$training_result$best_epoch,
      dims = list(
        p = p,
        n = n,
        h = 0,
        y = y_dim,
        levels = lvls,
        features = colnames(x)
      ),
      y_stats = y_stats,
      parameters = list(
        learn_rate = learn_rate,
        penalty = penalty,
        mixture = mixture,
        validation = validation,
        class_weights = class_weights,
        batch_size = batch_size,
        momentum = momentum
      ),
      device = device
    )
  }

multinomial_module <-
  torch::nn_module(
    "multinomial_reg_module",
    initialize = function(num_pred, num_classes) {
      self$fc1 <- torch::nn_linear(num_pred, num_classes)
      self$transform <- torch::nn_softmax(dim = 2)
    },
    forward = function(x) {
      x |>
        self$fc1() |>
        self$transform()
    }
  )

## -----------------------------------------------------------------------------

get_num_multinomial_reg_coef <- function(x) {
  model <- x$estimates[[1]]
  param <- vapply(model, function(.x) prod(dim(.x)), double(1))
  sum(unlist(param))
}

#' @export
print.brulee_multinomial_reg <- function(x, ...) {
  cat(cli::style_bold("Multinomial regression"), "\n\n", sep = "")
  brulee_print(x)
}
